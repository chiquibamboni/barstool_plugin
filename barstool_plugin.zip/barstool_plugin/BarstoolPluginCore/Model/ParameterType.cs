﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarstoolPluginCore.Model
{
    public enum ParameterType
    {
        LegDiameterD1,
        FootrestDiameterD2,
        SeatDiameterD,
        FootrestHeightH1,
        StoolHeightH,
        SeatDepthS
    }
}
